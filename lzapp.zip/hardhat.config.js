require("@nomiclabs/hardhat-waffle");

// This is a sample Hardhat task. To learn how to create your own go to
// https://hardhat.org/guides/create-task.html
task("accounts", "Prints the list of accounts", async (taskArgs, hre) => {
  const accounts = await hre.ethers.getSigners();

  for (const account of accounts) {
    console.log(account.address);
  }
});

// You need to export an object to set up your config
// Go to https://hardhat.org/config/ to learn more

/**
 * @type import('hardhat/config').HardhatUserConfig
 */

const URL = "https://rpc-mumbai.maticvigil.com"
const PRIVATE_KEY =
  "0x98258162a0b2017d79338cd2a5062f8a5164c83026dafb6cd8b36e3aaa099494";

module.exports = {
  solidity: "0.8.4",
  networks: {
    hardhat: {},
    ropsten: {
      url: process.env.ROPSTEN_URL || "",
      accounts: [PRIVATE_KEY],
    },
    mumbai: {
      url: URL,
      gasPrice: 35000000000,
      saveDeployments: true,
      accounts: [PRIVATE_KEY],
    },
    fuji: {
      url: process.env.FUJI_URL || "",
      accounts: [PRIVATE_KEY],
    },
    testnet: {
      url: process.env.FANTOM_TESTNET_URL || "",
      accounts: [PRIVATE_KEY],
    },
  },
  gasReporter: {
    enabled: process.env.REPORT_GAS !== undefined,
    currency: "USD",
  },
  etherscan: {
    apiKey: process.env.ETHERSCAN_API_KEY,
  },
};
